import java.util.*;

public class Servicios {
	
	private static long [][] biblioteca; //Hay 15 cub�culos cada �ndice de una fila+1 es un cubiculo
	private int indiceB;//Qu� cub�culo est� en uso en la matriz
	private boolean bibLlena;
	private int cubGrandes;
	private static long [][] gimnasio; //Hay 8 cupos por hora cada �ndice de una fila+1 es un cupo
	private boolean gimLleno;
	private static Map<String, Integer> solicitudB; //KEY: Code, VALUE: indice biblioteca
	private static Base_de_Datos db;
	
	public Servicios() {
		biblioteca = new long[15][2]; //Para la columna 0 se asigna si esta o no usada (1: si esta usada) (0: si no esta), para la columna 1 es el tiempo transcurrido
		gimnasio = new long[8][2]; 
		indiceB = 0;
		bibLlena = false;
		gimLleno = false;
		solicitudB = new TreeMap<>();
		db = new Base_de_Datos();
	}
	
	/**
	 * @param a:  numero de servicio 1: biblioteca, 2: gimnasio
	 * @param code: c�digo de usuario
	 */
	public void solServ(int a, String code)throws Exception { //Solicitar servicio
		if(a==1 && disponibilidad(a)) {//Servicio biblioteca
			if(indiceB < 14 && biblioteca[indiceB][0] == 0) {
				asignB(code);
			}
			else {
				if(indiceB == 14) {
					System.out.println("No hay cubiculos disponibles");
					bibLlena = true;
				}
				else {
					indiceB++;
					asignB(code);
				}
			}
		}
	}
	
	public String servSolicitado(String code) {
		if(solicitudB.containsKey(code)) {
			int a = solicitudB.get(code);
			return "El usuario " + db.getDatos(code).getName() + " tiene en uso el cubiculo de biblioteca #" + String.valueOf(a+1) ;
		}
		else return "No ha solicitado ningun servicio";
	}
	
	public void asignB(String code) {
		biblioteca[indiceB][0] = 1;
		biblioteca[indiceB][1] = Long.parseLong(code);
		solicitudB.put(code, indiceB);
		indiceB++;
	}
	
	private boolean disponibilidad(int a) {
		if(a==0 && bibLlena) {
			System.out.println("Todo los cub�culos est�n en uso.");
			return false;
		}
		else if(a==1 && gimLleno) {
			System.out.println("Los cupos del Gimnasio estpan llenos.");
			return false;
		}
		else return true;
	}

	private void calcTime() {
		long timeS , timeE = 0;
		timeS = System.currentTimeMillis();
		for(;;) {
			timeE = System.currentTimeMillis();
			if((timeE - timeS)/1000 == 7200) {//Se demora 7200s que equivale a 2 horas
				break;
			}
		}
		System.out.println((timeE - timeS)/1000/60);
	}
	
}
