import java.util.*;

/**
 * @category Esta clase es una Base de datos provisional
 *
 */
public class Base_de_Datos {
	
	/**
	 * El campo de dato -datos- representa cada uno de los miembros de la base de datos
	 * es un mapa que describe las siguientes caracteristicas
	 * Como Key contiene un tipo de dato String, el cu�l ser� un n�mero de 10 cifras (c�digo estudiantil)
	 * Como Value contiene un arreglo de Strings los cules van a representar el nombre, apellido, semestre, matriculado, jornada
	 */
	private static Map<String, Datos> datos; 
	
	public Base_de_Datos() {
		datos = new TreeMap<>();
		datos.put("1520010902", new Datos("Alejandro", "Arevalo", 6, true, false, 0));
		datos.put("1520010901", new Datos("Felipe", "Avenda�o", 6, true, true, 0));
		datos.put("1520010903", new Datos("Monica", "Ramirez", 5, true, false, 0));
		datos.put("1320014335", new Datos("Alfonso", "Duque", 7, true, false, 0));
		datos.put("1520010905", new Datos("Juan", "Ramirez", 5, true, false, 0));
		datos.put("1610011211", new Datos("Rogger", "Bogota", 5, true, false, 0));
		datos.put("1520010907", new Datos("Carolina", "Bohorquez", 1, true, true, 2));
		datos.put("1520010908", new Datos("Diego", "Oliveros", 0, true, true, 1));
		datos.put("1520010909", new Datos("Diego", "Satoba", -1, true, true, 1));
	}
	/**
	 * @param code : Codigo de estudiante
	 * @return Si el estudiante existe en la base de datos
	 */
	public boolean codeEx(String code) {
		return datos.containsKey(code);
	}
	/**
	 * @param code : Codigo de estudiante
	 * @return Datos del estudiante
	 */
	public Datos getDatos(String code) {
		return datos.get(code);
	}
	/**
	 * @param cd : Codigo de estudiante
	 * @param dt : Datos a agregar
	 */
	public void addDatos(String cd, Datos dt) {
		if(datos.containsKey(cd)) System.out.println("Ya existe el usuario con codigo " + cd + ".");
		else datos.put(cd, dt);
	}
    /**
     * @param cd : Codigo de estudiante
     * @param dt : Datos a modificar
      * @return Si fue posible su modificacion
     */
	public boolean modify(String cd, Datos dt) {
		if(datos.containsKey(cd)) datos.put(cd, dt);
		else return false;
		return true;
	}
}