import java.io.*;

public class Princ {

	private static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
	private static String code;
	private static Base_de_Datos db;
	private static Datos user;
	private static Servicios s = new Servicios();
	
	public static void main(String[] args) throws Exception{
		db = new Base_de_Datos();
		while(true) {
			if(verificacion()) {
				user = db.getDatos(code);
				System.out.println("Bienvenido " + user.getName() + " " + user.getLastName());			
			}
			
			election();
			out();
		}

	}
	
	public static boolean verificacion() throws Exception {
		System.out.print("Digite su c�digo estudiantil: ");
		code = in.readLine();
		while(code.length() != 10 || !db.codeEx(code)) {
			System.out.print("ERROR: C�digo no v�lido, digite de nuevo: ");
			code = in.readLine();
		}
		return true;
	}
	
	public static void election() throws Exception {
		System.out.println("Digite el servicio a elegir \n1: Biblioteca, 2: Gimnasio, 3: Ninguno");
		String election = in.readLine();
		if(election.equals("3")) out();
		while(!election.equals("1") && !election.equals("2")) {
			System.out.print("Eleccion no v�lida, digite de nuevo");
			election = in.readLine();
		}
		s.solServ(Integer.parseInt(election), code);
		System.out.println(s.servSolicitado(code));
	}
	
	public static void out() throws Exception{
		System.out.print("Desea salir? 1:Si, 2:No ");
		String a = in.readLine();
		if(a.equals("1")) {
			if(verificacion()) {
				user = db.getDatos(code);				
				System.out.println("Bienvenido " + user.getName() + " " + user.getLastName());
			}
		}
		else {
			election();
		}
	}
	
	public static String getCode() {
		return code;
	}
}
